package com.db.asgnmt.databasebuilder.gdc;


import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Table {
    private String serverLocation;
    private String serverUrl;
    private String serverUname;
    private String serverPass;

}
