package com.db.asgnmt.databasebuilder.gdc;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

@Setter
@Getter
public class GDC {
    // Getters and setters
    private HashMap<String, Table> GDC;


}


