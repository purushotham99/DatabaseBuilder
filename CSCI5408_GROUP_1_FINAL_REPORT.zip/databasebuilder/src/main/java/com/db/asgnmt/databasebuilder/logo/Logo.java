package com.db.asgnmt.databasebuilder.logo;

public class Logo {
	public static void displayLogo() {
		System.out.println("!!!!!!!      !!!!!!!");
		System.out.println("!!   !!      !!    !!");
		System.out.println("!!    !!     !!    !!");
		System.out.println("!!    !!     !!!!!!!");
		System.out.println("!!   !!      !!    !!");
		System.out.println("!!!!!!!      !!!!!!!");
		System.out.println("-----------------------");
		System.out.println("    BUILDER V.1.0      ");
	}

}
